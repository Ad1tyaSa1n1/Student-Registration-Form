// Point this to your FastAPI server. If serving the frontend from FastAPI itself,
// you can leave it as "" to use the same origin.
const API_BASE = "http://localhost:8000";

const form = document.getElementById("studentForm");
const message = document.getElementById("formMessage");
const tableBody = document.querySelector("#studentsTable tbody");
const refreshBtn = document.getElementById("refreshBtn");

function setMessage(text, type = "") {
  message.textContent = text;
  message.className = `message ${type}`;
}

async function loadStudents() {
  tableBody.innerHTML = `<tr><td colspan="6" class="empty">Loading…</td></tr>`;
  try {
    const res = await fetch(`${API_BASE}/api/students`);
    if (!res.ok) throw new Error("Failed to load");
    const students = await res.json();
    if (!students.length) {
      tableBody.innerHTML = `<tr><td colspan="6" class="empty">No students registered yet.</td></tr>`;
      return;
    }
    tableBody.innerHTML = students
      .map(
        (s) => `
        <tr>
          <td>${s.id}</td>
          <td>${escapeHtml(s.first_name)} ${escapeHtml(s.last_name)}</td>
          <td>${escapeHtml(s.email)}</td>
          <td>${escapeHtml(s.course)}</td>
          <td>${escapeHtml(s.phone || "—")}</td>
          <td><button class="btn danger small" data-id="${s.id}">Delete</button></td>
        </tr>`
      )
      .join("");
  } catch (err) {
    tableBody.innerHTML = `<tr><td colspan="6" class="empty">⚠️ Could not connect to API at ${API_BASE}</td></tr>`;
  }
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  setMessage("");

  const data = Object.fromEntries(new FormData(form).entries());
  // Strip empty optional fields
  Object.keys(data).forEach((k) => { if (data[k] === "") delete data[k]; });

  try {
    const res = await fetch(`${API_BASE}/api/students`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      const detail = body.detail || "Registration failed";
      setMessage(typeof detail === "string" ? detail : JSON.stringify(detail), "error");
      return;
    }
    setMessage(`✅ ${body.first_name} registered successfully!`, "success");
    form.reset();
    loadStudents();
  } catch (err) {
    setMessage("⚠️ Could not reach the server. Is FastAPI running?", "error");
  }
});

tableBody.addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-id]");
  if (!btn) return;
  if (!confirm("Delete this student?")) return;
  try {
    const res = await fetch(`${API_BASE}/api/students/${btn.dataset.id}`, { method: "DELETE" });
    if (!res.ok && res.status !== 204) throw new Error();
    loadStudents();
  } catch {
    setMessage("Failed to delete student.", "error");
  }
});

refreshBtn.addEventListener("click", loadStudents);
loadStudents();
