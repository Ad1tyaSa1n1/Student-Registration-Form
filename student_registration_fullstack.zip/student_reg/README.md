# Student Registration — Full Stack

A simple full-stack student registration system.

- **Frontend:** plain HTML, CSS, JavaScript (no build step)
- **Backend:** Python + FastAPI + SQLAlchemy + SQLite

## Project structure

```
student_reg/
├── backend/
│   ├── main.py
│   └── requirements.txt
└── frontend/
    ├── index.html
    ├── styles.css
    └── app.js
```

## 1. Run the backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

API runs on **http://localhost:8000**.
Interactive docs: **http://localhost:8000/docs**.

A `students.db` SQLite file is created automatically.

## 2. Run the frontend

Two options:

**A. Open directly:** double-click `frontend/index.html` (or any static server like `python -m http.server` from inside `frontend/`).

**B. Served by FastAPI:** just open **http://localhost:8000/** — the backend already serves the frontend folder.

## API endpoints

| Method | Path                    | Description           |
|--------|-------------------------|-----------------------|
| GET    | `/api/health`           | Health check          |
| POST   | `/api/students`         | Create a student      |
| GET    | `/api/students`         | List all students     |
| GET    | `/api/students/{id}`    | Get one student       |
| DELETE | `/api/students/{id}`    | Delete a student      |

## Configure the API URL

In `frontend/app.js`, edit:

```js
const API_BASE = "http://localhost:8000";
```

Set to `""` if you serve the frontend from FastAPI on the same origin.
